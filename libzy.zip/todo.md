
Librarian Must be able to collect penality for the books who is submitting it delay {due:2023-06-15} {start:2023-06-15T16:56:56}
Librarian Must be Ask a member to request for returning the borrowed books {due:2023-06-15} {start:2023-06-15T16:56:59}
Member must be able to capture the Reading status and completion status and completed date and etc



User Registration - There must be two different roles for Users, 1. Librarian 2. Member {cm:2023-06-14}
(A) Memember Module - Memeber must have a access for search books {cm:2023-06-14}
(A) Member must have a access for a Borrow books and return books {cm:2023-06-14}
Member must be able see the books that he has already borrowed {cm:2023-06-14}
Librarian Must be able to see the list of books available {cm:2023-06-14}
Librarian Must be able to change the role of a user from a Member to Librarian / Librarian to a member {cm:2023-06-14}
Librarian Must have a Access for Adding Books, Editing Books, Updating Books, Removing Books {due:2023-06-14} {cm:2023-06-14}
Librarian Must be able to see the list of books borrowed {due:2023-06-14} {cm:2023-06-15}